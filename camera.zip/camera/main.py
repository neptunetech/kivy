import kivy
from kivy.app import App
from kivy.uix.boxlayout import BoxLayout
from kivy.lang import Builder
import time

Builder.load_file('cameraclick.kv')

class CameraClick(BoxLayout):
    def build(self):

        camera = self.ids ['camera']
        timestr = time.strftime("%y%m%d_%H%M%S")
        camera.export_to_png("IMG_{}.png".format(timestr))
        print ("Captured")

class TestCamera(App):
    def build (self):
        return CameraClick()


TestCamera().run()
